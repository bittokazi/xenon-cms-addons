<?php
xenon_addon_details(array(
'name' => 'Xenon Mobile Theme Pack',
'reg_name' => 'xenon-mobile-theme-pack',
'description' => 'Adds mobile switch theme pack',
'dev_name' => 'Bitto Kazi'
));
?>